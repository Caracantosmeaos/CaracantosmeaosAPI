// import { get, TPlatformType } from './api'

// the blazeId is currently unknown and makes those endpoints unusable.

// export const getMembersClubStats = (platform: TPlatformType, clubId: number, blazeId: string) => get(platform, `clubs/${clubId}/members/${blazeId}/stats?filters=pretty`)
// export const getMembersStats = (platform: TPlatformType, blazeId: string) => get(platform, `members/${blazeId}/stats?filters=pretty`)

export const a = 0