export interface ISettings {
	divisionId: number
	divisionName: string
	pointsForPromotion: number
	pointsToHoldDivision: number
	pointsToTitle: number
}